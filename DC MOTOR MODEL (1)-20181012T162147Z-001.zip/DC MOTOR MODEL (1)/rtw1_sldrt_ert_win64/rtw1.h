/*
 * rtw1.h
 *
 * Code generation for model "rtw1".
 *
 * Model version              : 1.4
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 * C source code generated on : Fri Oct 12 16:38:06 2018
 *
 * Target selection: sldrtert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_rtw1_h_
#define RTW_HEADER_rtw1_h_
#include <float.h>
#include <string.h>
#ifndef rtw1_COMMON_INCLUDES_
# define rtw1_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "sldrtdef.h"
#endif                                 /* rtw1_COMMON_INCLUDES_ */

#include "rtw1_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               (&(rtm)->Timing.taskTime0)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T AnalogInput;                  /* '<Root>/Analog Input' */
  real_T AnalogInput1;                 /* '<Root>/Analog Input1' */
  real_T AnalogInput2;                 /* '<Root>/Analog Input2' */
  real_T TmpSignalConversionAtToWorkspaceInport1[3];
  real_T PulseGenerator;               /* '<Root>/Pulse Generator' */
} B_rtw1_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  void *AnalogInput_PWORK;             /* '<Root>/Analog Input' */
  void *AnalogInput1_PWORK;            /* '<Root>/Analog Input1' */
  void *AnalogInput2_PWORK;            /* '<Root>/Analog Input2' */
  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<Root>/Scope' */

  struct {
    void *LoggedData;
  } Scope1_PWORK;                      /* '<Root>/Scope1' */

  struct {
    void *LoggedData;
  } Scope2_PWORK;                      /* '<Root>/Scope2' */

  struct {
    void *LoggedData;
  } Scope3_PWORK;                      /* '<Root>/Scope3' */

  struct {
    void *LoggedData;
  } ToWorkspace_PWORK;                 /* '<Root>/To Workspace' */

  void *DigitalOutput_PWORK;           /* '<Root>/Digital Output' */
  int32_T clockTickCounter;            /* '<Root>/Pulse Generator' */
} DW_rtw1_T;

/* Parameters (default storage) */
struct P_rtw1_T_ {
  real_T DigitalOutput_FinalValue;     /* Mask Parameter: DigitalOutput_FinalValue
                                        * Referenced by: '<Root>/Digital Output'
                                        */
  real_T DigitalOutput_InitialValue;   /* Mask Parameter: DigitalOutput_InitialValue
                                        * Referenced by: '<Root>/Digital Output'
                                        */
  real_T AnalogInput_MaxMissedTicks;   /* Mask Parameter: AnalogInput_MaxMissedTicks
                                        * Referenced by: '<Root>/Analog Input'
                                        */
  real_T AnalogInput1_MaxMissedTicks;  /* Mask Parameter: AnalogInput1_MaxMissedTicks
                                        * Referenced by: '<Root>/Analog Input1'
                                        */
  real_T AnalogInput2_MaxMissedTicks;  /* Mask Parameter: AnalogInput2_MaxMissedTicks
                                        * Referenced by: '<Root>/Analog Input2'
                                        */
  real_T DigitalOutput_MaxMissedTicks; /* Mask Parameter: DigitalOutput_MaxMissedTicks
                                        * Referenced by: '<Root>/Digital Output'
                                        */
  real_T AnalogInput_YieldWhenWaiting; /* Mask Parameter: AnalogInput_YieldWhenWaiting
                                        * Referenced by: '<Root>/Analog Input'
                                        */
  real_T AnalogInput1_YieldWhenWaiting;/* Mask Parameter: AnalogInput1_YieldWhenWaiting
                                        * Referenced by: '<Root>/Analog Input1'
                                        */
  real_T AnalogInput2_YieldWhenWaiting;/* Mask Parameter: AnalogInput2_YieldWhenWaiting
                                        * Referenced by: '<Root>/Analog Input2'
                                        */
  real_T DigitalOutput_YieldWhenWaiting;/* Mask Parameter: DigitalOutput_YieldWhenWaiting
                                         * Referenced by: '<Root>/Digital Output'
                                         */
  int32_T DigitalOutput_BitMode;       /* Mask Parameter: DigitalOutput_BitMode
                                        * Referenced by: '<Root>/Digital Output'
                                        */
  int32_T AnalogInput_Channels;        /* Mask Parameter: AnalogInput_Channels
                                        * Referenced by: '<Root>/Analog Input'
                                        */
  int32_T AnalogInput1_Channels;       /* Mask Parameter: AnalogInput1_Channels
                                        * Referenced by: '<Root>/Analog Input1'
                                        */
  int32_T AnalogInput2_Channels;       /* Mask Parameter: AnalogInput2_Channels
                                        * Referenced by: '<Root>/Analog Input2'
                                        */
  int32_T DigitalOutput_Channels;      /* Mask Parameter: DigitalOutput_Channels
                                        * Referenced by: '<Root>/Digital Output'
                                        */
  int32_T AnalogInput_RangeMode;       /* Mask Parameter: AnalogInput_RangeMode
                                        * Referenced by: '<Root>/Analog Input'
                                        */
  int32_T AnalogInput1_RangeMode;      /* Mask Parameter: AnalogInput1_RangeMode
                                        * Referenced by: '<Root>/Analog Input1'
                                        */
  int32_T AnalogInput2_RangeMode;      /* Mask Parameter: AnalogInput2_RangeMode
                                        * Referenced by: '<Root>/Analog Input2'
                                        */
  int32_T AnalogInput_VoltRange;       /* Mask Parameter: AnalogInput_VoltRange
                                        * Referenced by: '<Root>/Analog Input'
                                        */
  int32_T AnalogInput1_VoltRange;      /* Mask Parameter: AnalogInput1_VoltRange
                                        * Referenced by: '<Root>/Analog Input1'
                                        */
  int32_T AnalogInput2_VoltRange;      /* Mask Parameter: AnalogInput2_VoltRange
                                        * Referenced by: '<Root>/Analog Input2'
                                        */
  real_T PulseGenerator_Amp;           /* Expression: 1
                                        * Referenced by: '<Root>/Pulse Generator'
                                        */
  real_T PulseGenerator_Period;        /* Computed Parameter: PulseGenerator_Period
                                        * Referenced by: '<Root>/Pulse Generator'
                                        */
  real_T PulseGenerator_Duty;          /* Computed Parameter: PulseGenerator_Duty
                                        * Referenced by: '<Root>/Pulse Generator'
                                        */
  real_T PulseGenerator_PhaseDelay;    /* Expression: 0
                                        * Referenced by: '<Root>/Pulse Generator'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_rtw1_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint16_T clockTick2;
    struct {
      uint16_T TID[3];
    } TaskCounters;

    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_rtw1_T rtw1_P;

/* Block signals (default storage) */
extern B_rtw1_T rtw1_B;

/* Block states (default storage) */
extern DW_rtw1_T rtw1_DW;

/* Model entry point functions */
extern void rtw1_initialize(void);
extern void rtw1_output(void);
extern void rtw1_update(void);
extern void rtw1_terminate(void);

/* Real-time Model object */
extern RT_MODEL_rtw1_T *const rtw1_M;

/* Simulink Desktop Real-Time specific functions */
time_T rtw1_sldrtGetTaskTime(int_T tid);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'rtw1'
 */
#endif                                 /* RTW_HEADER_rtw1_h_ */
