/*
 * rtw1.c
 *
 * Code generation for model "rtw1".
 *
 * Model version              : 1.4
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 * C source code generated on : Fri Oct 12 16:38:06 2018
 *
 * Target selection: sldrtert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw1.h"
#include "rtw1_private.h"
#include "rtw1_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  15.0,
  0.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.005, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "Measurement_Computing/PCI-DAS6025", 4294967295U, 5, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_rtw1_T rtw1_B;

/* Block states (default storage) */
DW_rtw1_T rtw1_DW;

/* Real-time model */
RT_MODEL_rtw1_T rtw1_M_;
RT_MODEL_rtw1_T *const rtw1_M = &rtw1_M_;
static void rate_scheduler(void);

/* Simulink Desktop Real-Time specific functions */
time_T rtw1_sldrtGetTaskTime(int_T tid)
{
  switch (tid) {
   case 0 :
    return(rtw1_M->Timing.taskTime0);
  }

  return(0.);
}

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (rtw1_M->Timing.TaskCounters.TID[1])++;
  if ((rtw1_M->Timing.TaskCounters.TID[1]) > 19) {/* Sample time: [0.1s, 0.0s] */
    rtw1_M->Timing.TaskCounters.TID[1] = 0;
  }

  (rtw1_M->Timing.TaskCounters.TID[2])++;
  if ((rtw1_M->Timing.TaskCounters.TID[2]) > 1999) {/* Sample time: [10.0s, 0.0s] */
    rtw1_M->Timing.TaskCounters.TID[2] = 0;
  }
}

/* Model output function */
void rtw1_output(void)
{
  /* S-Function (sldrtai): '<Root>/Analog Input' */
  /* S-Function Block: <Root>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) rtw1_P.AnalogInput_RangeMode;
    parm.rangeidx = rtw1_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1, &rtw1_P.AnalogInput_Channels,
                   &rtw1_B.AnalogInput, &parm);
  }

  /* S-Function (sldrtai): '<Root>/Analog Input1' */
  /* S-Function Block: <Root>/Analog Input1 */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) rtw1_P.AnalogInput1_RangeMode;
    parm.rangeidx = rtw1_P.AnalogInput1_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1, &rtw1_P.AnalogInput1_Channels,
                   &rtw1_B.AnalogInput1, &parm);
  }

  /* S-Function (sldrtai): '<Root>/Analog Input2' */
  /* S-Function Block: <Root>/Analog Input2 */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) rtw1_P.AnalogInput2_RangeMode;
    parm.rangeidx = rtw1_P.AnalogInput2_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 1, &rtw1_P.AnalogInput2_Channels,
                   &rtw1_B.AnalogInput2, &parm);
  }

  /* SignalConversion: '<Root>/TmpSignal ConversionAtTo WorkspaceInport1' */
  rtw1_B.TmpSignalConversionAtToWorkspaceInport1[0] = rtw1_B.AnalogInput;
  rtw1_B.TmpSignalConversionAtToWorkspaceInport1[1] = rtw1_B.AnalogInput1;
  rtw1_B.TmpSignalConversionAtToWorkspaceInport1[2] = rtw1_B.AnalogInput2;
  if (rtw1_M->Timing.TaskCounters.TID[2] == 0) {
    /* DiscretePulseGenerator: '<Root>/Pulse Generator' */
    rtw1_B.PulseGenerator = (rtw1_DW.clockTickCounter <
      rtw1_P.PulseGenerator_Duty) && (rtw1_DW.clockTickCounter >= 0) ?
      rtw1_P.PulseGenerator_Amp : 0.0;
    if (rtw1_DW.clockTickCounter >= rtw1_P.PulseGenerator_Period - 1.0) {
      rtw1_DW.clockTickCounter = 0;
    } else {
      rtw1_DW.clockTickCounter++;
    }

    /* End of DiscretePulseGenerator: '<Root>/Pulse Generator' */
  }

  if (rtw1_M->Timing.TaskCounters.TID[1] == 0) {
    /* S-Function (sldrtdo): '<Root>/Digital Output' */
    /* S-Function Block: <Root>/Digital Output */
    {
      RTBIO_DriverIO(0, DIGITALOUTPUT, IOWRITE, 1,
                     &rtw1_P.DigitalOutput_Channels, ((real_T*)
        (&rtw1_B.PulseGenerator)), &rtw1_P.DigitalOutput_BitMode);
    }
  }
}

/* Model update function */
void rtw1_update(void)
{
  /* signal main to stop simulation */
  {                                    /* Sample time: [0.005s, 0.0s] */
    if ((rtmGetTFinal(rtw1_M)!=-1) &&
        !((rtmGetTFinal(rtw1_M)-rtw1_M->Timing.taskTime0) >
          rtw1_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(rtw1_M, "Simulation finished");
    }

    if (rtmGetStopRequested(rtw1_M)) {
      rtmSetErrorStatus(rtw1_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  rtw1_M->Timing.taskTime0 =
    (++rtw1_M->Timing.clockTick0) * rtw1_M->Timing.stepSize0;
  if (rtw1_M->Timing.TaskCounters.TID[1] == 0) {
    /* Update absolute timer for sample time: [0.1s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.1, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    rtw1_M->Timing.clockTick1++;
  }

  if (rtw1_M->Timing.TaskCounters.TID[2] == 0) {
    /* Update absolute timer for sample time: [10.0s, 0.0s] */
    /* The "clockTick2" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 10.0, which is the step size
     * of the task. Size of "clockTick2" ensures timer will not overflow during the
     * application lifespan selected.
     */
    rtw1_M->Timing.clockTick2++;
  }

  rate_scheduler();
}

/* Model initialize function */
void rtw1_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)rtw1_M, 0,
                sizeof(RT_MODEL_rtw1_T));
  rtmSetTFinal(rtw1_M, -1);
  rtw1_M->Timing.stepSize0 = 0.005;

  /* External mode info */
  rtw1_M->Sizes.checksums[0] = (915293862U);
  rtw1_M->Sizes.checksums[1] = (3530798221U);
  rtw1_M->Sizes.checksums[2] = (2807409540U);
  rtw1_M->Sizes.checksums[3] = (1859519879U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    rtw1_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(rtw1_M->extModeInfo,
      &rtw1_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(rtw1_M->extModeInfo, rtw1_M->Sizes.checksums);
    rteiSetTPtr(rtw1_M->extModeInfo, rtmGetTPtr(rtw1_M));
  }

  /* block I/O */
  (void) memset(((void *) &rtw1_B), 0,
                sizeof(B_rtw1_T));

  /* states (dwork) */
  (void) memset((void *)&rtw1_DW, 0,
                sizeof(DW_rtw1_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    rtw1_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Start for DiscretePulseGenerator: '<Root>/Pulse Generator' */
  rtw1_DW.clockTickCounter = 0;

  /* Start for S-Function (sldrtdo): '<Root>/Digital Output' */

  /* S-Function Block: <Root>/Digital Output */
  {
    RTBIO_DriverIO(0, DIGITALOUTPUT, IOWRITE, 1, &rtw1_P.DigitalOutput_Channels,
                   &rtw1_P.DigitalOutput_InitialValue,
                   &rtw1_P.DigitalOutput_BitMode);
  }
}

/* Model terminate function */
void rtw1_terminate(void)
{
  /* Terminate for S-Function (sldrtdo): '<Root>/Digital Output' */

  /* S-Function Block: <Root>/Digital Output */
  {
    RTBIO_DriverIO(0, DIGITALOUTPUT, IOWRITE, 1, &rtw1_P.DigitalOutput_Channels,
                   &rtw1_P.DigitalOutput_FinalValue,
                   &rtw1_P.DigitalOutput_BitMode);
  }
}
